"""
VPN v3.1.1 (Brooklyn Bridge) integration test harness.

Spins up the v3_1_1 server and client in the same pytest process via threads.
TAP devices are replaced with FakeTap — an in-memory bidirectional queue —
since real TAP requires Windows + the OpenVPN TAP driver. The protocol layer
(FramedSocket, IPAM, SwitchPlane, TokenBucket, helpers) is exercised end to
end with real TCP sockets on ephemeral ports.

What this catches:
  - Wire protocol bugs (framing, hello/config exchange, ETH multiplexing)
  - IPAM allocation correctness (lease reuse, pool exhaustion, races)
  - SwitchPlane MAC learning + aging
  - TokenBucket rate limiting
  - Server lifecycle (boot, accept, client teardown)
  - Frame size clamping
  - Broadcast/multicast detection helpers

What this does NOT catch:
  - Real Windows TAP behavior (driver-specific quirks)
  - Real network MTU/fragmentation
  - ngrok / TLS layer (the TCP layer is local in tests)

Run: python3 -m pytest test_vpn_integration.py -v
"""

from __future__ import annotations

import json
import queue
import socket
import struct
import sys
import tempfile
import threading
import time
from contextlib import closing
from pathlib import Path

import pytest

# Path setup: tests live next to vpn_server.py / vpn_client.py
HERE = Path(__file__).parent
sys.path.insert(0, str(HERE))

import vpn_server as srv
import vpn_client as cli


# --------------- helpers ---------------


def _free_port() -> int:
    with closing(socket.socket(socket.AF_INET, socket.SOCK_STREAM)) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def _wait_for_port(port: int, timeout: float = 3.0) -> bool:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        try:
            with closing(socket.create_connection(("127.0.0.1", port), timeout=0.2)):
                return True
        except OSError:
            time.sleep(0.05)
    return False


# --------------- FakeTap ---------------


class FakeTap:
    """Substitute for TapDevice: in-memory queue with the same surface area.

    write_frame puts a frame into the inbound queue (so the server's
    _tap_rx_loop will read it and forward to clients).
    read_frame returns frames written by the server's TAP TX path
    (the in-memory analog of "what would have been written to the TAP").
    """
    def __init__(self, name: str = "", read_buf: int = 65536, use_overlapped: bool = False):
        self.name = name
        self.read_buf = read_buf
        self.use_overlapped = use_overlapped
        self.handle = "fake"
        self.closing = threading.Event()
        # Frames the server will read (push_inbound puts here)
        self._rx = queue.Queue()
        # Frames the server has written (test assertions read here)
        self._tx = queue.Queue()

    def open(self):
        return

    def close(self):
        self.closing.set()
        # Wake any blocking read by enqueueing None
        self._rx.put(None)

    def read_frame(self):
        try:
            f = self._rx.get(timeout=0.2)
        except queue.Empty:
            return None
        return f

    def write_frame(self, frame: bytes) -> bool:
        self._tx.put(frame)
        return True

    # Test helpers
    def push_inbound(self, frame: bytes):
        """Inject a frame as if it arrived on the TAP NIC."""
        self._rx.put(frame)

    def pop_outbound(self, timeout: float = 1.0):
        """Read a frame the server wrote toward the TAP."""
        try:
            return self._tx.get(timeout=timeout)
        except queue.Empty:
            return None


# --------------- ServerConfig builder ---------------


def make_server_cfg(tmpdir: Path, port: int) -> srv.ServerConfig:
    """Construct a minimal valid ServerConfig for tests."""
    return srv.ServerConfig(
        listen_host="127.0.0.1",
        listen_port=port,
        max_clients=10,
        tap_name="FAKE",
        tap_read_buf=65536,
        tap_use_overlapped=False,
        max_frame_bytes=1600,
        ethernet_frame_max=1600,
        flood_unknown_unicast=True,
        mac_age_seconds=300.0,
        heartbeat_interval_s=30.0,
        client_timeout_s=120.0,
        bcast_rate_pps=1000.0,
        bcast_burst=2000.0,
        bcast_per_client_pps=100.0,
        bcast_per_client_burst=200.0,
        ipam_pool_start="10.99.0.10",
        ipam_pool_end="10.99.0.20",
        ipam_gateway="10.99.0.1",
        ipam_mask="255.255.255.0",
        ipam_dns="8.8.8.8",
        ipam_lease_seconds=3600,
        ipam_db_path=str(tmpdir / "ipam.db"),
        debug_enabled=False,
        debug_level="WARNING",
        debug_log_file=str(tmpdir / "server.log"),
        debug_also_console=False,
        debug_log_packets=False,
        debug_log_packet_hex=False,
        debug_hex_max_len=64,
        pcap_enabled=False,
        pcap_dir=str(tmpdir / "pcaps"),
        pcap_prefix="server",
        pcap_split_direction=False,
    )


# --------------- harness ---------------


class VPNTestEnv:
    def __init__(self, tmpdir: Path):
        self.tmpdir = tmpdir
        self.port = _free_port()
        self.fake_tap = FakeTap()
        self.server: srv.VPNServerV311 = None
        self.server_thread: threading.Thread = None

    def start_server(self):
        cfg = make_server_cfg(self.tmpdir, self.port)
        self.server = srv.VPNServerV311(cfg)
        # Replace the TAP with our fake — same interface
        self.server.tap = self.fake_tap

        # We can't call server.start() because it blocks on stop_event.
        # Reproduce the non-blocking parts: open TAP (fake), bind socket,
        # start the threads.
        self.server.tap.open()
        self.server.listen_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server.listen_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.server.listen_sock.bind((cfg.listen_host, cfg.listen_port))
        self.server.listen_sock.listen(cfg.max_clients)

        self.server.tap_rx_thread.start()
        self.server.tap_tx_thread.start()
        self.server.accept_thread.start()
        self.server.house_thread.start()

        assert _wait_for_port(self.port, 3.0), "server didn't bind"
        return self.server

    def stop(self):
        if self.server is None:
            return
        try:
            self.server.stop()
        except Exception:
            pass
        # Force-close listen socket if stop() didn't
        try:
            if self.server.listen_sock:
                self.server.listen_sock.close()
        except Exception:
            pass
        try:
            self.fake_tap.close()
        except Exception:
            pass


@pytest.fixture
def env():
    with tempfile.TemporaryDirectory() as tmp:
        e = VPNTestEnv(Path(tmp))
        e.start_server()
        try:
            yield e
        finally:
            e.stop()


# --------------- ClientHarness ---------------


def make_client_cfg(server_host: str, server_port: int, client_id: str,
                    tmpdir: Path) -> cli.ClientConfig:
    """Construct a minimal valid ClientConfig for tests."""
    return cli.ClientConfig(
        server_host=server_host,
        server_port=server_port,
        client_id=client_id,
        protocol_version="3.1.1",
        tap_name="FAKE",
        tap_read_buf=65536,
        tap_use_overlapped=False,
        max_frame_bytes=1600,
        ethernet_frame_max=1600,
        heartbeat_interval_s=2.0,   # short for tests
        reconnect_delay_s=0.5,
        silent_timeout_s=30.0,
        apply_ip_config=False,        # don't run netsh in tests
        apply_mtu=False,
        apply_dns=False,
        apply_gateway=False,
        routes_persistent=False,
        routes=[],
        debug_enabled=False,
        debug_level="WARNING",
        debug_log_file=str(tmpdir / "client.log"),
        debug_also_console=False,
        debug_log_packets=False,
        debug_log_packet_hex=False,
        debug_hex_max_len=64,
        pcap_enabled=False,
        pcap_dir=str(tmpdir / "pcaps"),
        pcap_prefix="client",
        pcap_split_direction=False,
    )


class ClientHarness:
    """Spins up a VPNClientV311 with a FakeTap and a thread driving
    _connect_run. Exposes the FakeTap so tests can inject inbound frames
    and observe outbound ones."""

    def __init__(self, env: "VPNTestEnv", client_id: str):
        self.env = env
        self.client_id = client_id
        self.fake_tap = FakeTap()
        self.cfg = make_client_cfg(
            "127.0.0.1", env.port, client_id, env.tmpdir,
        )
        self.client = cli.VPNClientV311(self.cfg)
        # Replace TAP with our fake
        self.client.tap = self.fake_tap

        # Start TAP threads (they'll loop reading/writing the fake)
        self.client.tap_rx_thread.start()
        self.client.tap_tx_thread.start()

        # Drive _connect_run in its own thread so it can do the handshake
        # and stay attached. Note: _connect_run has a reconnect loop in
        # start(), but calling _connect_run directly is fine for a test —
        # it does the full handshake and stays attached until disconnect.
        self._driver = threading.Thread(target=self.client._connect_run, daemon=True)
        self._driver.start()

    def wait_for_config(self, timeout: float = 3.0) -> dict:
        """Block until the client has received and stored a CONFIG message."""
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            if self.client.assigned_cfg:
                return self.client.assigned_cfg
            time.sleep(0.05)
        raise TimeoutError(f"client {self.client_id} didn't receive CONFIG within {timeout}s")

    def stop(self):
        # The client's stop() now does shutdown-before-close cleanly,
        # so we just delegate to it instead of reaching into internals.
        try:
            self.client.stop()
        except Exception:
            pass
        try:
            self.fake_tap.close()
        except Exception:
            pass


def make_test_client_socket(env, hello: dict = None) -> srv.FramedSocket:
    """Open a TCP connection to the server and send a HELLO. Returns the
    FramedSocket-wrapped client end ready to receive CONFIG."""
    sock = socket.create_connection(("127.0.0.1", env.port), timeout=2.0)
    fs = srv.FramedSocket(sock, max_frame_bytes=1600, role="test_client")
    msg = hello or {"client_id": "test-client", "version": "v3.1.1"}
    fs.send_msg(srv.MSG_HELLO, json.dumps(msg).encode("utf-8"))
    return fs


def recv_with_type(fs: srv.FramedSocket, expected_type: int, timeout: float = 2.0) -> dict:
    """Read messages until we see one of the expected type. Returns parsed JSON."""
    fs.sock.settimeout(timeout)
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        result = fs.recv_msg()
        if result is None:
            raise RuntimeError("connection closed before expected msg")
        t, payload = result
        if t == expected_type:
            return json.loads(payload.decode("utf-8")) if payload else {}
        # Otherwise drain and keep looking (e.g. early heartbeat)
    raise TimeoutError(f"didn't receive type={expected_type} within {timeout}s")


# =====================================================================
# TESTS
# =====================================================================


class TestProtocolPrimitives:
    """Pure-function tests that don't need a live server."""

    def test_frame_hdr_struct(self):
        # !BI = network byte order, 1 byte type, 4 byte length = 5 bytes
        assert srv.FRAME_HDR.size == 5
        packed = srv.FRAME_HDR.pack(srv.MSG_HELLO, 100)
        assert len(packed) == 5
        t, length = srv.FRAME_HDR.unpack(packed)
        assert t == srv.MSG_HELLO
        assert length == 100

    def test_is_broadcast_mac(self):
        assert srv.is_broadcast_mac(b"\xff\xff\xff\xff\xff\xff") is True
        assert srv.is_broadcast_mac(b"\x00\x11\x22\x33\x44\x55") is False
        # Multicast that isn't broadcast
        assert srv.is_broadcast_mac(b"\x01\x00\x5e\x00\x00\x01") is False

    def test_is_multicast_mac(self):
        # Standard IPv4 multicast
        assert srv.is_multicast_mac(b"\x01\x00\x5e\x00\x00\x01") is True
        # Broadcast is also multicast (least-significant bit of first byte)
        assert srv.is_multicast_mac(b"\xff\xff\xff\xff\xff\xff") is True
        # Standard unicast
        assert srv.is_multicast_mac(b"\x00\x11\x22\x33\x44\x55") is False
        # IPv6 multicast 33:33
        assert srv.is_multicast_mac(b"\x33\x33\x00\x00\x00\x01") is True

    def test_is_broadcast_mac_defensive_against_empty(self):
        """v3.1.2: an empty bytes input must not crash."""
        assert srv.is_broadcast_mac(b"") is False
        assert srv.is_broadcast_mac(b"\xff\xff") is False  # too short

    def test_is_multicast_mac_defensive_against_empty(self):
        """v3.1.2: previously dst[0] would IndexError on empty bytes."""
        assert srv.is_multicast_mac(b"") is False  # was: IndexError


class TestTokenBucket:
    def test_initial_burst_allowed(self):
        tb = srv.TokenBucket(rate_per_sec=10.0, burst=20.0)
        # Should allow up to burst worth immediately
        for _ in range(20):
            assert tb.allow(1.0) is True
        # 21st should be denied (burst exhausted, no time has passed)
        assert tb.allow(1.0) is False

    def test_zero_rate_unlimited(self):
        """rate_per_sec <= 0 disables the bucket entirely."""
        tb = srv.TokenBucket(rate_per_sec=0.0, burst=1.0)
        for _ in range(1000):
            assert tb.allow(1.0) is True

    def test_refill_over_time(self):
        tb = srv.TokenBucket(rate_per_sec=100.0, burst=1.0)
        # Drain
        assert tb.allow(1.0) is True
        assert tb.allow(1.0) is False
        # Wait long enough to refill ≥1 token
        time.sleep(0.05)  # 0.05s * 100 = 5 tokens, capped at burst=1
        assert tb.allow(1.0) is True


class TestIPAM:
    def _make(self, tmp_path):
        return srv.SQLiteIPAM(
            db_path=str(tmp_path / "ipam.db"),
            pool_start="10.99.0.10",
            pool_end="10.99.0.12",  # tiny pool of 3 addresses
            lease_seconds=3600,
        )

    def test_allocate_first_address(self, tmp_path):
        ipam = self._make(tmp_path)
        ip = ipam.allocate("client-key-1", "host-1")
        assert ip == "10.99.0.10"

    def test_repeat_allocation_returns_same_ip(self, tmp_path):
        """Same client_key gets same lease while it's still valid."""
        ipam = self._make(tmp_path)
        ip1 = ipam.allocate("client-key-1", "host-1")
        ip2 = ipam.allocate("client-key-1", "host-1")
        assert ip1 == ip2

    def test_different_clients_get_different_ips(self, tmp_path):
        ipam = self._make(tmp_path)
        ip1 = ipam.allocate("client-key-1", "host-1")
        ip2 = ipam.allocate("client-key-2", "host-2")
        ip3 = ipam.allocate("client-key-3", "host-3")
        assert ip1 == "10.99.0.10"
        assert ip2 == "10.99.0.11"
        assert ip3 == "10.99.0.12"

    def test_pool_exhaustion_raises(self, tmp_path):
        ipam = self._make(tmp_path)
        ipam.allocate("k1", "h1")
        ipam.allocate("k2", "h2")
        ipam.allocate("k3", "h3")
        with pytest.raises(RuntimeError, match="exhausted"):
            ipam.allocate("k4", "h4")

    def test_client_id_can_change(self, tmp_path):
        """Same client_key, different label — should work and update label."""
        ipam = self._make(tmp_path)
        ip1 = ipam.allocate("client-key-1", "host-original")
        ip2 = ipam.allocate("client-key-1", "host-renamed")
        assert ip1 == ip2  # same lease

    def test_persistent_across_instances(self, tmp_path):
        """A new IPAM instance pointing at the same DB file recovers leases."""
        ipam1 = self._make(tmp_path)
        ip1 = ipam1.allocate("persistent-key", "host-1")
        ipam2 = self._make(tmp_path)  # fresh instance, same DB
        ip2 = ipam2.allocate("persistent-key", "host-1")
        assert ip1 == ip2


class TestSwitchPlane:
    def test_learn_and_lookup(self):
        sp = srv.SwitchPlane(flood_unknown=True, mac_age_s=300.0)
        mac = b"\x00\x11\x22\x33\x44\x55"
        assert sp.lookup(mac) is None
        sp.learn(mac, "client-A")
        assert sp.lookup(mac) == "client-A"

    def test_unknown_mac_returns_none(self):
        sp = srv.SwitchPlane(flood_unknown=True, mac_age_s=300.0)
        assert sp.lookup(b"\xde\xad\xbe\xef\x00\x01") is None

    def test_relearn_overwrites(self):
        """If a MAC moves to a different client (rare but possible), relearn updates."""
        sp = srv.SwitchPlane(flood_unknown=True, mac_age_s=300.0)
        mac = b"\x00\x11\x22\x33\x44\x55"
        sp.learn(mac, "client-A")
        sp.learn(mac, "client-B")
        assert sp.lookup(mac) == "client-B"

    def test_aging_removes_stale_entries(self):
        sp = srv.SwitchPlane(flood_unknown=True, mac_age_s=0.05)  # 50ms age
        mac = b"\x00\x11\x22\x33\x44\x55"
        sp.learn(mac, "client-A")
        assert sp.lookup(mac) == "client-A"
        time.sleep(0.06)
        # lookup itself prunes expired entries
        assert sp.lookup(mac) is None


class TestServerLifecycle:
    def test_server_binds_on_configured_port(self, env):
        assert _wait_for_port(env.port, 1.0)

    def test_two_envs_dont_collide(self):
        with tempfile.TemporaryDirectory() as t1, tempfile.TemporaryDirectory() as t2:
            e1 = VPNTestEnv(Path(t1))
            e2 = VPNTestEnv(Path(t2))
            e1.start_server()
            try:
                e2.start_server()
                assert e1.port != e2.port
            finally:
                e1.stop()
                e2.stop()


class TestHandshake:
    def test_client_receives_config_after_hello(self, env):
        fs = make_test_client_socket(env, {
            "client_id": "alpha", "version": "v3.1.1",
        })
        try:
            cfg_msg = recv_with_type(fs, srv.MSG_CONFIG, timeout=2.0)
            assert "assigned_ip" in cfg_msg, f"CONFIG missing 'assigned_ip': {cfg_msg}"
            assert "subnet_mask" in cfg_msg, f"CONFIG missing 'subnet_mask': {cfg_msg}"
            assert "gateway" in cfg_msg, f"CONFIG missing 'gateway': {cfg_msg}"
            assert "session_key" in cfg_msg, f"CONFIG missing 'session_key': {cfg_msg}"
        finally:
            fs.sock.close()

    def test_assigned_ip_is_in_pool(self, env):
        fs = make_test_client_socket(env)
        try:
            cfg_msg = recv_with_type(fs, srv.MSG_CONFIG, timeout=2.0)
            ip = cfg_msg["assigned_ip"]
            import ipaddress
            assert ipaddress.ip_address(ip) >= ipaddress.ip_address("10.99.0.10")
            assert ipaddress.ip_address(ip) <= ipaddress.ip_address("10.99.0.20")
        finally:
            fs.sock.close()

    def test_two_clients_get_different_ips(self, env):
        fs1 = make_test_client_socket(env, {"client_id": "alpha"})
        fs2 = make_test_client_socket(env, {"client_id": "beta"})
        try:
            cfg1 = recv_with_type(fs1, srv.MSG_CONFIG, timeout=2.0)
            cfg2 = recv_with_type(fs2, srv.MSG_CONFIG, timeout=2.0)
            assert cfg1["assigned_ip"] != cfg2["assigned_ip"]
        finally:
            fs1.sock.close()
            fs2.sock.close()

    def test_server_tracks_connected_client(self, env):
        fs = make_test_client_socket(env)
        try:
            recv_with_type(fs, srv.MSG_CONFIG, timeout=2.0)
            time.sleep(0.2)
            assert len(env.server.clients_by_key) == 1
        finally:
            fs.sock.close()


class TestEthernetForwarding:
    def test_client_eth_to_tap(self, env):
        """A client sends an Ethernet frame; server should forward to TAP."""
        fs = make_test_client_socket(env)
        try:
            recv_with_type(fs, srv.MSG_CONFIG, timeout=2.0)
            # Build a synthetic Ethernet frame (no real semantics, just bytes)
            # dst=01:00:5e:00:00:01 (multicast), src=00:11:22:33:44:55
            frame = b"\x01\x00\x5e\x00\x00\x01" + b"\x00\x11\x22\x33\x44\x55" + b"\x08\x00" + b"X" * 50
            fs.send_msg(srv.MSG_DATA_ETHERNET, frame)
            # Server should write something to the (fake) TAP
            out = env.fake_tap.pop_outbound(timeout=2.0)
            assert out is not None, "server did not forward client frame to TAP"
            assert out == frame
        finally:
            fs.sock.close()

    def test_tap_eth_to_client_via_flood(self, env):
        """A frame arriving on TAP toward an unknown unicast destination
        should flood to all connected clients (when flood_unknown_unicast=True)."""
        fs = make_test_client_socket(env)
        try:
            recv_with_type(fs, srv.MSG_CONFIG, timeout=2.0)
            time.sleep(0.2)  # let the client register fully

            # Push a frame onto the TAP RX path (as if it arrived from the LAN).
            # Use a broadcast destination so it definitely floods.
            frame = b"\xff\xff\xff\xff\xff\xff" + b"\x00\x11\x22\x33\x44\x55" + b"\x08\x06" + b"Y" * 30
            env.fake_tap.push_inbound(frame)

            # Client should receive a MSG_DATA_ETHERNET on the TCP wire
            fs.sock.settimeout(2.0)
            t, payload = fs.recv_msg()
            # First message after CONFIG might be heartbeat; loop a couple times
            for _ in range(5):
                if t == srv.MSG_DATA_ETHERNET:
                    break
                t, payload = fs.recv_msg()
            assert t == srv.MSG_DATA_ETHERNET
            assert payload == frame
        finally:
            fs.sock.close()


class TestProtocolRobustness:
    def test_garbage_payload_doesnt_crash_server(self, env):
        """A client that sends garbage on the wire should be dropped without
        crashing the server or affecting other clients."""
        # Healthy client
        good_fs = make_test_client_socket(env, {"client_id": "good"})
        try:
            recv_with_type(good_fs, srv.MSG_CONFIG, timeout=2.0)

            # Bad client: send a valid frame header but garbage as JSON in HELLO
            bad = socket.create_connection(("127.0.0.1", env.port))
            try:
                # Type=MSG_HELLO, length=10, payload="not-json!!"
                bad.sendall(srv.FRAME_HDR.pack(srv.MSG_HELLO, 10) + b"not-json!!")
                time.sleep(0.5)
            finally:
                bad.close()

            # Good client should still be alive and able to send a frame
            good_fs.send_msg(
                srv.MSG_DATA_ETHERNET,
                b"\xff\xff\xff\xff\xff\xff\x00\x11\x22\x33\x44\x55\x08\x00" + b"Z" * 40,
            )
            out = env.fake_tap.pop_outbound(timeout=2.0)
            assert out is not None, "good client lost service after bad client misbehaved"
        finally:
            good_fs.sock.close()

    def test_oversized_frame_dropped(self, env):
        """A client sending a frame larger than max_frame_bytes should not
        crash the server. The server should close the offending connection."""
        bad = socket.create_connection(("127.0.0.1", env.port))
        try:
            # Claim 10 MB payload — wildly past the 1600-byte clamp
            bad.sendall(srv.FRAME_HDR.pack(srv.MSG_HELLO, 10 * 1024 * 1024))
            # Server should close the connection with a ValueError on its side
            time.sleep(0.5)
        finally:
            bad.close()

        # Server should still accept a fresh client
        good = make_test_client_socket(env, {"client_id": "after-bad"})
        try:
            recv_with_type(good, srv.MSG_CONFIG, timeout=2.0)
        finally:
            good.sock.close()

    def test_client_disconnect_cleans_up_session(self, env):
        fs = make_test_client_socket(env)
        try:
            recv_with_type(fs, srv.MSG_CONFIG, timeout=2.0)
            time.sleep(0.2)
            assert len(env.server.clients_by_key) == 1
        finally:
            fs.sock.close()
        # Give the server's RX loop time to notice EOF
        time.sleep(0.5)
        assert len(env.server.clients_by_key) == 0, \
            f"server did not clean up disconnected session: {list(env.server.clients_by_key)}"


class TestRuntFrameHandling:
    """Frames smaller than 14 bytes (Ethernet header minimum) should be
    rejected without polluting the MAC table or crashing."""

    def test_runt_frame_from_client_drops_cleanly(self, env):
        """A 5-byte 'frame' from a client is too short to even parse a MAC.
        Server should drop it as a runt and not crash."""
        fs = make_test_client_socket(env)
        try:
            recv_with_type(fs, srv.MSG_CONFIG, timeout=2.0)
            # 5-byte payload — less than Ethernet header (14 bytes)
            fs.send_msg(srv.MSG_DATA_ETHERNET, b"\x01\x02\x03\x04\x05")
            time.sleep(0.3)
            counters = env.server.counters.snapshot()
            assert counters.get("drops.client_runt", 0) >= 1, \
                f"runt drop counter not incremented: {counters}"
        finally:
            fs.sock.close()

    def test_runt_frame_from_tap_drops_cleanly(self, env):
        """A runt frame coming in from the TAP RX path should not crash
        the server. Regression against the bug where _tap_rx_loop would
        learn() a partial src MAC from a 12-byte frame before the runt
        check at the next stage rejected it."""
        # Push a 12-byte 'frame' onto the TAP — long enough for line 800's
        # `len(frame) >= 12` check to attempt a learn from frame[6:12], but
        # too short to be a valid Ethernet frame (need 14 bytes).
        runt = b"\x00\x11\x22\x33\x44\x55" + b"\xaa\xbb\xcc\xdd\xee\xff"  # 12 bytes
        env.fake_tap.push_inbound(runt)
        time.sleep(0.3)

        # The src MAC \xaa\xbb\xcc\xdd\xee\xff should NOT have been learned
        # to the switch table — that would be data-corruption from a
        # malformed frame.
        # Currently this test FAILS as the bug exists. The fix is to move
        # the runt check before the learn in _tap_rx_loop.
        learned = env.server.switch.lookup(b"\xaa\xbb\xcc\xdd\xee\xff")
        assert learned is None, \
            f"server learned MAC from a runt frame: {learned!r}"


class TestIPAMReconnectBehavior:
    """v3.1.1 deliberately keys IPAM on session_key (not client_id) to
    avoid spoofing. Document what that means in practice."""

    def test_reconnect_with_same_client_id_gets_new_ip(self, env):
        """Documented behavior, not a bug: when a client disconnects and
        reconnects with the same client_id, it gets a fresh session_key
        and therefore a fresh IPAM lease — burning one address from the
        pool until the original lease expires.

        This is the deliberate trade-off in v3.1.1 (anti-spoofing). If
        long-running deployments see pool exhaustion from frequent
        reconnects, the fix is shorter lease times — not changing the key.
        """
        fs1 = make_test_client_socket(env, {"client_id": "rebooting-client"})
        cfg1 = recv_with_type(fs1, srv.MSG_CONFIG, timeout=2.0)
        ip1 = cfg1["assigned_ip"]
        fs1.sock.close()
        time.sleep(0.4)  # let server clean up

        fs2 = make_test_client_socket(env, {"client_id": "rebooting-client"})
        try:
            cfg2 = recv_with_type(fs2, srv.MSG_CONFIG, timeout=2.0)
            ip2 = cfg2["assigned_ip"]
            # Different IP — fresh allocation per session
            assert ip1 != ip2, (
                f"expected fresh allocation per session, but got same IP {ip1}. "
                "If this changed, v3.1.1's anti-spoofing model also changed."
            )
        finally:
            fs2.sock.close()


class TestMACLearning:
    """End-to-end MAC learning: a frame from client A teaches the server
    where A's MAC lives, so a later frame from the TAP toward that MAC
    goes directly to A (not flooded)."""

    def test_unicast_after_learning_goes_to_correct_client(self, env):
        # Client A sends a frame revealing its MAC
        fs_a = make_test_client_socket(env, {"client_id": "alpha"})
        try:
            recv_with_type(fs_a, srv.MSG_CONFIG, timeout=2.0)
            mac_a = b"\xaa\xaa\xaa\xaa\xaa\xaa"
            # A unicast frame from A: dst doesn't matter for learning, src does
            frame_from_a = (
                b"\x00\x11\x22\x33\x44\x55"  # dst (some other host)
                + mac_a                       # src = A's MAC
                + b"\x08\x00"                 # ethertype IPv4
                + b"X" * 40
            )
            fs_a.send_msg(srv.MSG_DATA_ETHERNET, frame_from_a)
            time.sleep(0.3)

            # Now check the switch table
            target = env.server.switch.lookup(mac_a)
            assert target is not None, "A's MAC was not learned"

            # Send a frame INTO the TAP (simulating a host on the LAN)
            # destined for A's MAC. It should land specifically on A,
            # not be flooded.
            frame_to_a = (
                mac_a                          # dst = A's MAC
                + b"\x00\x11\x22\x33\x44\x55"  # src
                + b"\x08\x00"
                + b"Y" * 40
            )
            env.fake_tap.push_inbound(frame_to_a)

            # A should receive it
            fs_a.sock.settimeout(1.5)
            received = None
            for _ in range(8):
                t, payload = fs_a.recv_msg()
                if t == srv.MSG_DATA_ETHERNET and payload == frame_to_a:
                    received = payload
                    break
            assert received == frame_to_a, "A did not receive directed unicast"
        finally:
            fs_a.sock.close()


# =====================================================================
# REAL CLIENT TESTS — both ends are real VPNClientV311 / VPNServerV311
# =====================================================================


class TestRealClientHandshake:
    def test_real_client_completes_handshake(self, env):
        """The full client class connects, handshakes, and stores its
        assigned config. Exercises the real _connect_run + _net_rx_loop
        path end to end."""
        h = ClientHarness(env, client_id="real-alpha")
        try:
            cfg = h.wait_for_config(timeout=3.0)
            assert "assigned_ip" in cfg
            assert cfg["assigned_ip"].startswith("10.99.0.")
            assert h.client.session_key is not None
            assert h.client.session_key.startswith("127.0.0.1:")
        finally:
            h.stop()

    def test_real_client_appears_in_server_table(self, env):
        h = ClientHarness(env, client_id="real-beta")
        try:
            h.wait_for_config(timeout=3.0)
            time.sleep(0.2)
            # Server should know about this session keyed by session_key
            sk = h.client.session_key
            assert sk in env.server.clients_by_key, \
                f"client session_key {sk!r} not in server.clients_by_key={list(env.server.clients_by_key)}"
            # And the client_id label should match
            sess = env.server.clients_by_key[sk]
            assert sess.client_id == "real-beta"
        finally:
            h.stop()

    def test_two_real_clients(self, env):
        ha = ClientHarness(env, client_id="dual-a")
        hb = ClientHarness(env, client_id="dual-b")
        try:
            ca = ha.wait_for_config(timeout=3.0)
            cb = hb.wait_for_config(timeout=3.0)
            assert ca["assigned_ip"] != cb["assigned_ip"]
            assert ha.client.session_key != hb.client.session_key
        finally:
            ha.stop()
            hb.stop()


class TestRealClientForwarding:
    def test_tap_to_server_to_client(self, env):
        """A frame the client writes to its TAP (i.e. its OS stack sends
        a packet) should travel up the tunnel and arrive on the server's
        TAP when the destination is unknown (flood)."""
        h = ClientHarness(env, client_id="tap-tx-test")
        try:
            h.wait_for_config(timeout=3.0)
            time.sleep(0.2)

            # Client's OS would normally write to its TAP. Simulate by
            # injecting into the FakeTap's RX queue (which the client's
            # _tap_rx_loop will read and forward to the server).
            mac_client = b"\x02\x00\x00\x00\xa1\x01"
            mac_other = b"\x02\x00\x00\x00\xa1\x02"
            frame = (
                mac_other     # dst — not yet learned by server
                + mac_client  # src
                + b"\x08\x00"
                + b"hello"
            )
            h.fake_tap.push_inbound(frame)

            # Server should have ended up writing it onto its TAP (the fake)
            out = env.fake_tap.pop_outbound(timeout=2.0)
            assert out is not None, "frame did not reach server's TAP"
            assert out == frame
        finally:
            h.stop()

    def test_server_tap_to_client_tap(self, env):
        """Frame arriving on server's TAP gets flooded to client; client
        writes it to its (fake) TAP."""
        h = ClientHarness(env, client_id="rx-test")
        try:
            h.wait_for_config(timeout=3.0)
            time.sleep(0.2)

            # Push a broadcast frame onto the SERVER's TAP
            broadcast_frame = (
                b"\xff\xff\xff\xff\xff\xff"
                + b"\x02\x00\x00\x00\x99\x01"
                + b"\x08\x06"  # ARP ethertype
                + b"BROADCAST-PAYLOAD"
            )
            env.fake_tap.push_inbound(broadcast_frame)

            # The client should write this frame onto its (fake) TAP
            received = h.fake_tap.pop_outbound(timeout=2.0)
            assert received is not None, "client did not write frame to its TAP"
            assert received == broadcast_frame
        finally:
            h.stop()

    def test_client_to_client_via_server_switching(self, env):
        """Two real clients: A sends a frame with B's MAC as destination.
        The server should learn A's MAC, route the frame to B, who
        receives it on its TAP."""
        ha = ClientHarness(env, client_id="A")
        hb = ClientHarness(env, client_id="B")
        try:
            ha.wait_for_config(timeout=3.0)
            hb.wait_for_config(timeout=3.0)
            time.sleep(0.2)

            mac_a = b"\x02\x00\x00\xaa\xaa\xaa"
            mac_b = b"\x02\x00\x00\xbb\xbb\xbb"

            # First, B sends a frame so the server learns mac_b → B's session
            frame_from_b = mac_a + mac_b + b"\x08\x00" + b"FROM-B"
            hb.fake_tap.push_inbound(frame_from_b)
            time.sleep(0.3)

            # Confirm server learned mac_b
            sk_b = hb.client.session_key
            assert env.server.switch.lookup(mac_b) == sk_b, \
                "server did not learn B's MAC"

            # Drain anything on A's TAP from this learning step
            while ha.fake_tap.pop_outbound(timeout=0.1) is not None:
                pass

            # Now A sends a frame addressed to B's MAC
            frame_from_a = mac_b + mac_a + b"\x08\x00" + b"FROM-A-TO-B"
            ha.fake_tap.push_inbound(frame_from_a)

            # B should receive it on its TAP. (NOT A — unicast, not flood.)
            got_b = hb.fake_tap.pop_outbound(timeout=2.0)
            assert got_b == frame_from_a, \
                f"B did not receive frame from A: {got_b!r}"

            # A should NOT have received its own frame back
            got_a = ha.fake_tap.pop_outbound(timeout=0.5)
            assert got_a is None, \
                f"A received its own frame back (loopback bug): {got_a!r}"
        finally:
            ha.stop()
            hb.stop()


    def test_client_drops_runt_from_tap(self, env):
        """v3.1.2: client should drop runts at TAP RX before sending them
        across the tunnel. Saves wire traffic and matches server bounds."""
        h = ClientHarness(env, client_id="runt-client")
        try:
            h.wait_for_config(timeout=3.0)
            time.sleep(0.2)

            # Drain anything pending on the server's TAP from learning steps
            while env.fake_tap.pop_outbound(timeout=0.1) is not None:
                pass

            # Inject a runt onto the client's TAP
            h.fake_tap.push_inbound(b"\x00\x11\x22\x33\x44\x55")  # 6 bytes
            time.sleep(0.4)

            # The client should NOT have forwarded this. Server's TAP queue
            # should still be empty.
            forwarded = env.fake_tap.pop_outbound(timeout=0.3)
            assert forwarded is None, \
                f"client forwarded a runt frame to server: {forwarded!r}"

            # And the client's drop counter should be incremented
            counters = h.client.counters.snapshot()
            assert counters.get("drops.runt_eth", 0) >= 1, \
                f"runt drop counter not incremented: {counters}"
        finally:
            h.stop()


class TestRealClientLifecycle:
    def test_client_disconnect_cleans_up_server_session(self, env):
        h = ClientHarness(env, client_id="lifecycle")
        try:
            h.wait_for_config(timeout=3.0)
            time.sleep(0.2)
            sk = h.client.session_key
            assert sk in env.server.clients_by_key
        finally:
            h.stop()
        # Give server's RX loop time to notice the closed socket
        time.sleep(0.6)
        assert sk not in env.server.clients_by_key, \
            "server didn't clean up session after client stop"

    def test_client_heartbeat_reaches_server(self, env):
        """The client's _net_tx_loop sends MSG_HEARTBEAT periodically.
        The server should record rx.heartbeat counter increments."""
        h = ClientHarness(env, client_id="heartbeat-test")
        try:
            h.wait_for_config(timeout=3.0)
            # Heartbeat interval is 2s in test config; wait for at least 2
            time.sleep(5.0)
            counters = env.server.counters.snapshot()
            hb_count = counters.get("rx.heartbeat", 0)
            assert hb_count >= 1, \
                f"server did not receive any heartbeats (counters: {counters})"
        finally:
            h.stop()
