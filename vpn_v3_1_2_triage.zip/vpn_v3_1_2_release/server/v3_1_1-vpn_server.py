#!/usr/bin/env python3
"""
N2NHU Brooklyn Bridge - Server v3.1.1 (OPEN / bring-up reliable)

Changes vs v3.1:
- TAP I/O defaults to synchronous blocking ReadFile/WriteFile (most reliable on Windows TAP)
- Optional overlapped mode remains possible but OFF by default
- Frame size clamp (default 1600 bytes) before tunneling (protects ngrok / avoids TSO jumbo surprises)
- Soft broadcast/multicast rate limiting (token bucket) to avoid one client melting everyone
- Client ID collision safe: server assigns unique session_key; client_id is a label only
- Clean shutdown (no os._exit); proper stop + join-ish behavior
"""

import argparse
import configparser
import ipaddress
import json
import os
import queue
import signal
import socket
import sqlite3
import struct
import threading
import time
from dataclasses import dataclass
from typing import Dict, Optional, Tuple, Any

# v3.1.2: Make Win32 imports conditional. The protocol layer (FramedSocket,
# IPAM, SwitchPlane, helpers) is fully testable on any platform; only the
# TAP device requires Windows. Fail late, not at module import.
try:
    import win32file
    import win32con
    import pywintypes
    _WIN32_OK = True
    _WIN32_IMPORT_ERROR = None
except ImportError as _e:
    _WIN32_OK = False
    _WIN32_IMPORT_ERROR = _e
    win32file = None
    win32con = None
    pywintypes = None

# Optional debugger module
try:
    from vpn_debugger import DebugProbe, ProbeConfig, setup_rotating_file_logger
except Exception:
    DebugProbe = None
    ProbeConfig = None
    setup_rotating_file_logger = None


# =========================
# Protocol
# =========================
MSG_DATA_ETHERNET = 0x01
MSG_HELLO         = 0x02
MSG_CONFIG        = 0x03
MSG_HEARTBEAT     = 0x04
MSG_STATS         = 0x05
MSG_ERROR         = 0x06

FRAME_HDR = struct.Struct("!BI")  # Type (1 byte) + Length (4 bytes big-endian)


# =========================
# Helpers
# =========================
def now() -> float:
    return time.time()

def _bool(s: str) -> bool:
    return str(s).strip().lower() in ("1", "true", "yes", "y", "on")

def _int(s: str, default: int) -> int:
    try:
        return int(str(s).strip())
    except Exception:
        return default

def _float(s: str, default: float) -> float:
    try:
        return float(str(s).strip())
    except Exception:
        return default

def rate_limited(logger_fn, key: str, interval_s: float, msg: str, state: dict):
    t = state.get(key, 0.0)
    n = now()
    if n - t >= interval_s:
        state[key] = n
        logger_fn(msg)


def is_broadcast_mac(dst: bytes) -> bool:
    return len(dst) >= 6 and dst[:6] == b"\xff\xff\xff\xff\xff\xff"

def is_multicast_mac(dst: bytes) -> bool:
    # v3.1.2: defensive against short input — empty/short bytes are neither
    # broadcast nor multicast (treat as malformed; caller should drop earlier).
    return len(dst) >= 1 and (dst[0] & 1) == 1


# =========================
# Token bucket (soft DoS protection)
# =========================
class TokenBucket:
    def __init__(self, rate_per_sec: float, burst: float):
        self.rate = float(rate_per_sec)
        self.burst = float(burst)
        self.tokens = float(burst)
        self.last = now()
        self.lock = threading.Lock()

    def allow(self, cost: float = 1.0) -> bool:
        if self.rate <= 0:
            return True
        with self.lock:
            t = now()
            elapsed = max(0.0, t - self.last)
            self.last = t
            self.tokens = min(self.burst, self.tokens + elapsed * self.rate)
            if self.tokens >= cost:
                self.tokens -= cost
                return True
            return False


# =========================
# Configuration
# =========================
@dataclass
class ServerConfig:
    listen_host: str
    listen_port: int
    max_clients: int

    tap_name: str
    tap_read_buf: int
    tap_use_overlapped: bool

    max_frame_bytes: int
    ethernet_frame_max: int  # hard clamp, e.g. 1600

    flood_unknown_unicast: bool
    mac_age_seconds: float

    heartbeat_interval_s: float
    client_timeout_s: float

    # Broadcast controls
    bcast_rate_pps: float
    bcast_burst: float
    bcast_per_client_pps: float
    bcast_per_client_burst: float

    # IPAM
    ipam_pool_start: str
    ipam_pool_end: str
    ipam_gateway: str
    ipam_mask: str
    ipam_dns: str
    ipam_lease_seconds: int
    ipam_db_path: str

    # Debug
    debug_enabled: bool
    debug_level: str
    debug_log_file: str
    debug_also_console: bool
    debug_log_packets: bool
    debug_log_packet_hex: bool
    debug_hex_max_len: int

    pcap_enabled: bool
    pcap_dir: str
    pcap_prefix: str
    pcap_split_direction: bool


def load_config(path: str) -> ServerConfig:
    p = configparser.ConfigParser()
    p.read(path)

    def opt(sec, key, default=""):
        return p.get(sec, key, fallback=default)

    listen_host = opt("server", "listen_host", "0.0.0.0")
    listen_port = _int(opt("server", "listen_port", "4444"), 4444)
    max_clients  = _int(opt("server", "max_clients", "50"), 50)

    tap_name = opt("tap", "name", "N2NHU-Server-TAP")
    tap_read_buf = _int(opt("tap", "read_buf", "65536"), 65536)
    tap_use_overlapped = _bool(opt("tap", "use_overlapped", "false"))  # OFF by default for reliability

    max_frame_bytes = _int(opt("transport", "max_frame_bytes", "262144"), 262144)

    # HARD ethernet clamp to protect tunnels / ngrok and avoid huge TSO surprises
    ethernet_frame_max = _int(opt("transport", "ethernet_frame_max", "1600"), 1600)

    flood_unknown_unicast = _bool(opt("mac_learning", "flood_unknown_unicast", "true"))
    mac_age_seconds = _float(opt("mac_learning", "mac_age_seconds", "300"), 300.0)

    heartbeat_interval_s = _float(opt("transport", "heartbeat_interval_seconds", "5"), 5.0)
    client_timeout_s = _float(opt("transport", "client_timeout_seconds", "30"), 30.0)

    bcast_rate_pps = _float(opt("broadcast", "global_pps", "200"), 200.0)
    bcast_burst = _float(opt("broadcast", "global_burst", "500"), 500.0)
    bcast_per_client_pps = _float(opt("broadcast", "per_client_pps", "50"), 50.0)
    bcast_per_client_burst = _float(opt("broadcast", "per_client_burst", "100"), 100.0)

    ipam_pool_start = opt("ipam", "pool_start", "10.50.50.50")
    ipam_pool_end   = opt("ipam", "pool_end", "10.50.50.250")
    ipam_gateway    = opt("ipam", "gateway", "10.50.50.1")
    ipam_mask       = opt("ipam", "subnet_mask", "255.255.255.0")
    ipam_dns        = opt("ipam", "dns", ipam_gateway)
    ipam_lease_seconds = _int(opt("ipam", "lease_seconds", "86400"), 86400)
    ipam_db_path    = opt("ipam", "sqlite_db", "vpn_ipam.db")

    debug_enabled = _bool(opt("debug", "enabled", "true"))
    debug_level = opt("debug", "level", "TRACE")
    debug_log_file = opt("debug", "log_file", "vpn_server_trace.log")
    debug_also_console = _bool(opt("debug", "also_console", "false"))
    debug_log_packets = _bool(opt("debug", "log_packets", "true"))
    debug_log_packet_hex = _bool(opt("debug", "log_packet_hex", "false"))
    debug_hex_max_len = _int(opt("debug", "hex_max_len", "96"), 96)

    pcap_enabled = _bool(opt("debug", "pcap_enabled", "true"))
    pcap_dir = opt("debug", "pcap_dir", "logs")
    pcap_prefix = opt("debug", "pcap_prefix", "vpn_v3")
    pcap_split_direction = _bool(opt("debug", "pcap_split_direction", "true"))

    return ServerConfig(
        listen_host=listen_host, listen_port=listen_port, max_clients=max_clients,
        tap_name=tap_name, tap_read_buf=tap_read_buf, tap_use_overlapped=tap_use_overlapped,
        max_frame_bytes=max_frame_bytes, ethernet_frame_max=ethernet_frame_max,
        flood_unknown_unicast=flood_unknown_unicast, mac_age_seconds=mac_age_seconds,
        heartbeat_interval_s=heartbeat_interval_s, client_timeout_s=client_timeout_s,
        bcast_rate_pps=bcast_rate_pps, bcast_burst=bcast_burst,
        bcast_per_client_pps=bcast_per_client_pps, bcast_per_client_burst=bcast_per_client_burst,
        ipam_pool_start=ipam_pool_start, ipam_pool_end=ipam_pool_end,
        ipam_gateway=ipam_gateway, ipam_mask=ipam_mask, ipam_dns=ipam_dns,
        ipam_lease_seconds=ipam_lease_seconds, ipam_db_path=ipam_db_path,
        debug_enabled=debug_enabled, debug_level=debug_level, debug_log_file=debug_log_file,
        debug_also_console=debug_also_console, debug_log_packets=debug_log_packets,
        debug_log_packet_hex=debug_log_packet_hex, debug_hex_max_len=debug_hex_max_len,
        pcap_enabled=pcap_enabled, pcap_dir=pcap_dir, pcap_prefix=pcap_prefix,
        pcap_split_direction=pcap_split_direction
    )


# =========================
# Counters
# =========================
class Counters:
    def __init__(self):
        self.lock = threading.Lock()
        self.c: Dict[str, int] = {}

    def inc(self, k: str, n: int = 1):
        with self.lock:
            self.c[k] = self.c.get(k, 0) + n

    def snapshot(self) -> Dict[str, int]:
        with self.lock:
            return dict(self.c)


# =========================
# Framed socket
# =========================
class FramedSocket:
    def __init__(self, sock: socket.socket, max_frame_bytes: int, probe=None, role=""):
        self.sock = sock
        self.max_frame_bytes = max_frame_bytes
        self.probe = probe
        self.role = role
        self.send_lock = threading.Lock()

    def _recv_exact(self, n: int) -> Optional[bytes]:
        buf = b""
        while len(buf) < n:
            chunk = self.sock.recv(n - len(buf))
            if not chunk:
                return None
            buf += chunk
        return buf

    def recv_msg(self) -> Optional[Tuple[int, bytes]]:
        hdr = self._recv_exact(FRAME_HDR.size)
        if hdr is None:
            return None
        t, length = FRAME_HDR.unpack(hdr)
        if length < 0 or length > self.max_frame_bytes:
            raise ValueError(f"invalid_length={length}")
        payload = self._recv_exact(length)
        if payload is None:
            return None
        if self.probe:
            try: self.probe.msg("RX", t, length, role=self.role)
            except Exception: pass
        return t, payload

    def send_msg(self, t: int, payload: bytes):
        pkt = FRAME_HDR.pack(t, len(payload)) + payload
        with self.send_lock:
            self.sock.sendall(pkt)
        if self.probe:
            try: self.probe.msg("TX", t, len(payload), role=self.role)
            except Exception: pass


# =========================
# TAP device (sync default)
# =========================
class TapDevice:
    def __init__(self, name: str, read_buf: int, use_overlapped: bool):
        self.name = name
        self.read_buf = read_buf
        self.use_overlapped = use_overlapped
        self.handle = None
        self.closing = threading.Event()

    def open(self):
        if not _WIN32_OK:
            raise RuntimeError(
                f"TAP device requires Windows + pywin32 (import error: {_WIN32_IMPORT_ERROR})"
            )
        # BEST PRACTICE: use GUID in INI: {GUID}
        n = self.name.strip()
        paths = []
        if n.startswith("{") and n.endswith("}"):
            paths.append(r"\\.\Global\%s.tap" % n)
        paths.append(r"\\.\Global\%s.tap" % n)

        last = None
        flags = win32con.FILE_ATTRIBUTE_SYSTEM
        if self.use_overlapped:
            flags |= win32con.FILE_FLAG_OVERLAPPED

        for p in paths:
            try:
                self.handle = win32file.CreateFile(
                    p,
                    win32con.GENERIC_READ | win32con.GENERIC_WRITE,
                    0, None, win32con.OPEN_EXISTING,
                    flags, None
                )
                return
            except pywintypes.error as e:
                last = e
        raise last or RuntimeError("Failed to open TAP device")

    def close(self):
        self.closing.set()
        if self.handle:
            try:
                win32file.CancelIoEx(self.handle, None)
            except Exception:
                pass
            try:
                win32file.CloseHandle(self.handle)
            except Exception:
                pass
            self.handle = None

    def read_frame(self) -> Optional[bytes]:
        if not self.handle:
            return None

        if not self.use_overlapped:
            # Synchronous blocking read (reliable for TAP bring-up)
            try:
                data = win32file.ReadFile(self.handle, self.read_buf, None)[1]
                return bytes(data)
            except pywintypes.error as e:
                # broken pipe / handle closed
                if getattr(e, "winerror", None) in (109, 232, 995):
                    return None
                raise

        # Overlapped mode can be implemented later as a proper outstanding read ring.
        # For now, keep OFF by default.
        return None

    def write_frame(self, frame: bytes) -> bool:
        if not self.handle:
            return False
        try:
            win32file.WriteFile(self.handle, frame, None)
            return True
        except pywintypes.error as e:
            if getattr(e, "winerror", None) in (109, 232, 995):
                return False
            raise


# =========================
# IPAM (SQLite)
# =========================
class SQLiteIPAM:
    def __init__(self, db_path: str, pool_start: str, pool_end: str, lease_seconds: int):
        self.db_path = db_path
        self.pool_start = ipaddress.ip_address(pool_start)
        self.pool_end = ipaddress.ip_address(pool_end)
        self.lease_seconds = lease_seconds
        self.lock = threading.Lock()
        self._init_db()

    def _init_db(self):
        os.makedirs(os.path.dirname(self.db_path) or ".", exist_ok=True)
        con = sqlite3.connect(self.db_path)
        try:
            cur = con.cursor()
            cur.execute("""
                CREATE TABLE IF NOT EXISTS vpn_clients (
                    client_key TEXT PRIMARY KEY,
                    client_id TEXT,
                    ip TEXT NOT NULL,
                    lease_expires INTEGER NOT NULL,
                    last_seen INTEGER NOT NULL
                )
            """)
            con.commit()
        finally:
            con.close()

    def allocate(self, client_key: str, client_id: str) -> str:
        with self.lock:
            con = sqlite3.connect(self.db_path)
            try:
                cur = con.cursor()
                t = int(time.time())

                cur.execute("SELECT ip, lease_expires FROM vpn_clients WHERE client_key=?", (client_key,))
                row = cur.fetchone()
                if row:
                    ip, exp = row
                    if exp > t:
                        cur.execute("UPDATE vpn_clients SET last_seen=?, client_id=? WHERE client_key=?",
                                    (t, client_id, client_key))
                        con.commit()
                        return ip

                cur.execute("SELECT ip, lease_expires FROM vpn_clients")
                used = {ip for ip, exp in cur.fetchall() if exp > t}

                candidate = self.pool_start
                chosen = None
                while candidate <= self.pool_end:
                    s = str(candidate)
                    if s not in used:
                        chosen = s
                        break
                    candidate += 1

                if not chosen:
                    raise RuntimeError("IPAM pool exhausted")

                exp = t + self.lease_seconds
                cur.execute("""
                    INSERT INTO vpn_clients (client_key, client_id, ip, lease_expires, last_seen)
                    VALUES (?, ?, ?, ?, ?)
                    ON CONFLICT(client_key) DO UPDATE SET client_id=excluded.client_id, ip=excluded.ip,
                        lease_expires=excluded.lease_expires, last_seen=excluded.last_seen
                """, (client_key, client_id, chosen, exp, t))
                con.commit()
                return chosen
            finally:
                con.close()


# =========================
# SwitchPlane
# =========================
class SwitchPlane:
    def __init__(self, flood_unknown: bool, mac_age_s: float):
        self.flood_unknown = flood_unknown
        self.mac_age_s = mac_age_s
        self.lock = threading.Lock()
        self.table: Dict[bytes, Tuple[str, float]] = {}  # mac -> (target, ts)

    def learn(self, mac: bytes, target: str):
        with self.lock:
            self.table[mac] = (target, now())

    def lookup(self, mac: bytes) -> Optional[str]:
        with self.lock:
            ent = self.table.get(mac)
            if not ent:
                return None
            target, ts = ent
            if now() - ts > self.mac_age_s:
                del self.table[mac]
                return None
            return target

    def age(self):
        cutoff = now() - self.mac_age_s
        with self.lock:
            dead = [m for m, (_, ts) in self.table.items() if ts < cutoff]
            for m in dead:
                del self.table[m]


# =========================
# Client Session
# =========================
class ClientSession:
    def __init__(self, sock: socket.socket, addr, cfg: ServerConfig, counters: Counters, probe=None):
        self.sock = sock
        self.addr = addr
        self.cfg = cfg
        self.counters = counters
        self.probe = probe

        self.session_key = f"{addr[0]}:{addr[1]}:{int(now()*1000)}"
        self.client_id = "unknown"
        self.client_version = "unknown"
        self.last_seen = now()

        self.fs = FramedSocket(sock, cfg.max_frame_bytes, probe=probe, role="server")

        self.tx_q = queue.Queue(maxsize=2000)
        self.stop = threading.Event()
        self.warn_state = {}

        self.bcast_bucket = TokenBucket(cfg.bcast_per_client_pps, cfg.bcast_per_client_burst)

        self.on_hello = None
        self.on_eth = None
        self.on_disconnect = None

        self.rx_thread = threading.Thread(target=self._rx_loop, daemon=True)
        self.tx_thread = threading.Thread(target=self._tx_loop, daemon=True)

    def start_threads(self):
        self.rx_thread.start()
        self.tx_thread.start()

    def shutdown(self):
        self.stop.set()
        try:
            self.sock.shutdown(socket.SHUT_RDWR)
        except Exception:
            pass
        try:
            self.sock.close()
        except Exception:
            pass

    def send_config(self, obj: dict):
        self.fs.send_msg(MSG_CONFIG, json.dumps(obj).encode("utf-8"))

    def enqueue_eth(self, frame: bytes):
        try:
            self.tx_q.put_nowait(frame)
        except queue.Full:
            self.counters.inc("drops.client_tx_q_full")
            if self.probe:
                rate_limited(self.probe.warn, "client_tx_q_full", 2.0,
                             f"client_tx_q_full key={self.session_key} id={self.client_id}",
                             self.warn_state)

    def _rx_loop(self):
        try:
            while not self.stop.is_set():
                msg = self.fs.recv_msg()
                if msg is None:
                    break
                t, payload = msg
                self.last_seen = now()
                self.counters.inc("rx.msg_total")

                if t == MSG_HELLO:
                    self.counters.inc("rx.hello")
                    try:
                        obj = json.loads(payload.decode("utf-8", errors="replace"))
                    except Exception:
                        obj = {}
                    self.client_id = obj.get("client_id") or obj.get("id") or "unknown"
                    self.client_version = str(obj.get("protocol_version") or obj.get("version") or "unknown")
                    if self.on_hello:
                        self.on_hello(self, obj)

                elif t == MSG_DATA_ETHERNET:
                    self.counters.inc("rx.eth")
                    if self.on_eth:
                        self.on_eth(self, payload)

                elif t == MSG_HEARTBEAT:
                    self.counters.inc("rx.heartbeat")

                elif t == MSG_STATS:
                    self.counters.inc("rx.stats")

                else:
                    self.counters.inc("rx.unknown_type")
        except Exception as e:
            self.counters.inc("errors.client_rx_exception")
            if self.probe:
                try: self.probe.error(f"client_rx_exception key={self.session_key} err={e}")
                except Exception: pass
        finally:
            if self.on_disconnect:
                self.on_disconnect(self)

    def _tx_loop(self):
        hb_next = now() + self.cfg.heartbeat_interval_s
        try:
            while not self.stop.is_set():
                t = now()
                if t >= hb_next:
                    try:
                        self.fs.send_msg(MSG_HEARTBEAT, b"")
                        self.counters.inc("tx.heartbeat")
                    except Exception:
                        break
                    hb_next = t + self.cfg.heartbeat_interval_s

                try:
                    frame = self.tx_q.get(timeout=0.2)
                except queue.Empty:
                    continue

                try:
                    self.fs.send_msg(MSG_DATA_ETHERNET, frame)
                    self.counters.inc("tx.eth")
                except Exception:
                    break
        finally:
            self.shutdown()


# =========================
# Server
# =========================
class VPNServerV311:
    def __init__(self, cfg: ServerConfig):
        self.cfg = cfg
        self.counters = Counters()
        self.stop_event = threading.Event()
        self.warn_state = {}

        # Probe
        self.probe = None
        if DebugProbe and ProbeConfig and setup_rotating_file_logger:
            try:
                logger = setup_rotating_file_logger(
                    name="vpn-server",
                    log_file=cfg.debug_log_file,
                    level=cfg.debug_level,
                    also_console=cfg.debug_also_console
                )
                pc = ProbeConfig(
                    enabled=cfg.debug_enabled,
                    level=cfg.debug_level,
                    log_file=cfg.debug_log_file,
                    also_console=cfg.debug_also_console,
                    log_packets=cfg.debug_log_packets,
                    log_packet_hex=cfg.debug_log_packet_hex,
                    hex_max_len=cfg.debug_hex_max_len,
                    pcap_enabled=cfg.pcap_enabled,
                    pcap_dir=cfg.pcap_dir,
                    pcap_prefix=cfg.pcap_prefix,
                    pcap_split_direction=cfg.pcap_split_direction
                )
                self.probe = DebugProbe(logger, pc)
            except Exception:
                self.probe = None

        self.tap = TapDevice(cfg.tap_name, cfg.tap_read_buf, cfg.tap_use_overlapped)
        self.switch = SwitchPlane(cfg.flood_unknown_unicast, cfg.mac_age_seconds)
        self.ipam = SQLiteIPAM(cfg.ipam_db_path, cfg.ipam_pool_start, cfg.ipam_pool_end, cfg.ipam_lease_seconds)

        self.global_bcast_bucket = TokenBucket(cfg.bcast_rate_pps, cfg.bcast_burst)

        self.clients_lock = threading.Lock()
        self.clients_by_key: Dict[str, ClientSession] = {}

        self.switch_to_tap_q = queue.Queue(maxsize=5000)

        self.tap_rx_thread = threading.Thread(target=self._tap_rx_loop, daemon=True)
        self.tap_tx_thread = threading.Thread(target=self._tap_tx_loop, daemon=True)
        self.accept_thread = threading.Thread(target=self._accept_loop, daemon=True)
        self.house_thread = threading.Thread(target=self._housekeeping_loop, daemon=True)

        self.listen_sock: Optional[socket.socket] = None

    def info(self, s: str):
        if self.probe:
            try: self.probe.info(s); return
            except Exception: pass
        print(s, flush=True)

    def warn(self, s: str):
        if self.probe:
            try: self.probe.warn(s); return
            except Exception: pass
        print("WARN:", s, flush=True)

    def start(self):
        self.info("server v3.1.1 OPEN starting (sync TAP I/O, size clamp, soft bcast limiting)")
        self.tap.open()

        self.listen_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.listen_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.listen_sock.bind((self.cfg.listen_host, self.cfg.listen_port))
        self.listen_sock.listen(self.cfg.max_clients)

        self.tap_rx_thread.start()
        self.tap_tx_thread.start()
        self.accept_thread.start()
        self.house_thread.start()

        while not self.stop_event.is_set():
            time.sleep(0.5)

        self.stop()

    def stop(self):
        self.stop_event.set()
        try:
            if self.listen_sock:
                self.listen_sock.close()
        except Exception:
            pass
        self.listen_sock = None

        with self.clients_lock:
            sessions = list(self.clients_by_key.values())
            self.clients_by_key.clear()
        for s in sessions:
            s.shutdown()

        self.tap.close()

    def _accept_loop(self):
        while not self.stop_event.is_set():
            try:
                self.listen_sock.settimeout(1.0)
                sock, addr = self.listen_sock.accept()
            except socket.timeout:
                continue
            except Exception:
                break

            self.counters.inc("accept.total")
            sess = ClientSession(sock, addr, self.cfg, self.counters, probe=self.probe)
            sess.on_hello = self._on_hello
            sess.on_eth = self._on_client_eth
            sess.on_disconnect = self._on_disconnect

            with self.clients_lock:
                self.clients_by_key[sess.session_key] = sess

            sess.start_threads()

    def _on_hello(self, sess: ClientSession, hello: dict):
        # Allocate lease keyed by session_key to avoid client_id collision spoofing
        ip = self.ipam.allocate(sess.session_key, sess.client_id)

        cfg_obj = {
            "client_id": sess.client_id,
            "session_key": sess.session_key,
            "protocol_version": 3.1,
            "assigned_ip": ip,
            "subnet_mask": self.cfg.ipam_mask,
            "gateway": self.cfg.ipam_gateway,
            "dns": self.cfg.ipam_dns,
        }
        sess.send_config(cfg_obj)
        self.info(f"HELLO key={sess.session_key} id={sess.client_id} ver={sess.client_version} ip={ip} addr={sess.addr}")

    def _on_disconnect(self, sess: ClientSession):
        with self.clients_lock:
            self.clients_by_key.pop(sess.session_key, None)
        self.info(f"DISCONNECT key={sess.session_key} id={sess.client_id} addr={sess.addr}")

    def _clamp_and_count(self, frame: bytes, origin: str) -> bool:
        if len(frame) > self.cfg.ethernet_frame_max:
            self.counters.inc("drops.oversize_eth")
            if self.probe:
                rate_limited(self.probe.warn, f"oversize_{origin}", 2.0,
                             f"oversize_eth origin={origin} len={len(frame)} clamp={self.cfg.ethernet_frame_max}",
                             self.warn_state)
            return False
        return True

    def _tap_rx_loop(self):
        while not self.stop_event.is_set():
            frame = self.tap.read_frame()
            if not frame:
                continue
            self.counters.inc("tap.rx_frames")

            if not self._clamp_and_count(frame, "tap"):
                continue

            # v3.1.2: Runt check BEFORE learning. Previously a 12-13 byte
            # frame would have its src learned as __LOCAL__ from frame[6:12]
            # and then get dropped as a runt at the next stage — polluting
            # the switch table with MACs from malformed frames.
            if len(frame) < 14:
                self.counters.inc("drops.tap_runt")
                continue

            # Server local ingress => learn as __LOCAL__
            src = frame[6:12]
            self.switch.learn(src, "__LOCAL__")

            self._switch_ingress_from_tap(frame)

    def _switch_ingress_from_tap(self, frame: bytes):
        if len(frame) < 14:
            self.counters.inc("drops.runt")
            return
        dst = frame[0:6]
        # broadcast/mcast: flood to all clients (subject to global bucket)
        if is_broadcast_mac(dst) or is_multicast_mac(dst):
            if not self.global_bcast_bucket.allow(1.0):
                self.counters.inc("drops.bcast_global_rate")
                return
            self._flood_to_clients(frame, sender_key=None)
            return

        out = self.switch.lookup(dst)
        if out is None:
            if self.cfg.flood_unknown_unicast:
                self._flood_to_clients(frame, sender_key=None)
            else:
                self.counters.inc("drops.unknown_unicast")
        elif out == "__LOCAL__":
            # already local
            pass
        else:
            self._send_to_target(out, frame)

    def _send_to_target(self, target: str, frame: bytes):
        # target is either "__LOCAL__" or a session_key
        if target == "__LOCAL__":
            self._enqueue_to_tap(frame)
            return
        with self.clients_lock:
            sess = self.clients_by_key.get(target)
        if not sess:
            self.counters.inc("drops.target_missing")
            return
        sess.enqueue_eth(frame)

    def _flood_to_clients(self, frame: bytes, sender_key: Optional[str]):
        with self.clients_lock:
            sessions = list(self.clients_by_key.items())
        for key, sess in sessions:
            if sender_key and key == sender_key:
                continue
            sess.enqueue_eth(frame)
        self.counters.inc("tx.flood")

    def _on_client_eth(self, sess: ClientSession, frame: bytes):
        self.counters.inc("from_client.eth")

        if not self._clamp_and_count(frame, "client"):
            return
        if len(frame) < 14:
            self.counters.inc("drops.client_runt")
            return

        dst = frame[0:6]
        src = frame[6:12]

        # learn: src -> this client's session_key
        self.switch.learn(src, sess.session_key)

        bcast = is_broadcast_mac(dst) or is_multicast_mac(dst)

        # Rate limit broadcast per-client + global
        if bcast:
            if not sess.bcast_bucket.allow(1.0):
                self.counters.inc("drops.bcast_per_client_rate")
                return
            if not self.global_bcast_bucket.allow(1.0):
                self.counters.inc("drops.bcast_global_rate")
                return
            # deliver to TAP + flood to others
            self._enqueue_to_tap(frame)
            self._flood_to_clients(frame, sender_key=sess.session_key)
            return

        out = self.switch.lookup(dst)
        if out is None:
            if self.cfg.flood_unknown_unicast:
                self._enqueue_to_tap(frame)
                self._flood_to_clients(frame, sender_key=sess.session_key)
            else:
                self.counters.inc("drops.client_unknown_unicast")
        elif out == "__LOCAL__":
            self._enqueue_to_tap(frame)
        elif out == sess.session_key:
            self.counters.inc("drops.loopback_same_client")
        else:
            self._send_to_target(out, frame)

    def _enqueue_to_tap(self, frame: bytes):
        try:
            self.switch_to_tap_q.put_nowait(frame)
        except queue.Full:
            self.counters.inc("drops.switch_to_tap_q_full")
            if self.probe:
                rate_limited(self.probe.warn, "switch_to_tap_q_full", 2.0,
                             "switch_to_tap_q_full (dropping under pressure)", self.warn_state)

    def _tap_tx_loop(self):
        while not self.stop_event.is_set():
            try:
                frame = self.switch_to_tap_q.get(timeout=0.2)
            except queue.Empty:
                continue
            ok = self.tap.write_frame(frame)
            if ok:
                self.counters.inc("tap.tx_frames")
            else:
                self.counters.inc("errors.tap_write_failed")

    def _housekeeping_loop(self):
        stats_next = now() + 5.0
        while not self.stop_event.is_set():
            time.sleep(1.0)
            self.switch.age()

            # timeouts
            dead = []
            with self.clients_lock:
                for key, sess in list(self.clients_by_key.items()):
                    if now() - sess.last_seen > self.cfg.client_timeout_s:
                        dead.append((key, sess))
            for key, sess in dead:
                self.warn(f"TIMEOUT key={key} id={sess.client_id}")
                sess.shutdown()
                with self.clients_lock:
                    self.clients_by_key.pop(key, None)

            # periodic stats log
            if now() >= stats_next:
                snap = self.counters.snapshot()
                if self.probe:
                    try:
                        self.probe.info(f"stats {json.dumps(snap, sort_keys=True)}")
                    except Exception:
                        pass
                stats_next = now() + 5.0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="server_v3.ini")
    args = ap.parse_args()

    cfg = load_config(args.config)
    srv = VPNServerV311(cfg)

    def handle_sig(signum, frame):
        srv.warn(f"signal {signum} received, stopping...")
        srv.stop()

    signal.signal(signal.SIGINT, handle_sig)
    signal.signal(signal.SIGTERM, handle_sig)

    srv.start()


if __name__ == "__main__":
    main()
