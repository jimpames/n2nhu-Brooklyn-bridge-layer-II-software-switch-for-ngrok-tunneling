@echo off
cd /d "%~dp0"
echo Starting NGROK tunnel...
ngrok tcp 2222 --subdomain customer
