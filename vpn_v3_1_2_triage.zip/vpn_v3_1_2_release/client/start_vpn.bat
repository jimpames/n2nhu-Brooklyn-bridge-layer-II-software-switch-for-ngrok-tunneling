@echo off
cd /d "%~dp0"

echo.
echo ======================================================================
echo   N2NHU VPN Client - Starting...
echo ======================================================================
echo.

python v12.1-nms-client-PRODUCTION.py
pause
