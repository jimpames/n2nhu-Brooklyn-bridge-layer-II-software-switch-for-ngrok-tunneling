#!/usr/bin/env python3
"""
N2NHU Brooklyn Bridge - Client v3.1.1 (OPEN / bring-up reliable)

Pairs with Server v3.1.1:
- Framed protocol: [Type:1][Length:4][Payload], FRAME_HDR = "!BI"
- TAP I/O defaults to synchronous blocking ReadFile/WriteFile (most reliable for TAP on Windows)
- Hard frame size clamp before tunneling (default 1600) to protect tunnels / ngrok, avoid TSO jumbo issues
- Explicit counters + rate-limited warnings (no silent queue pressure)
- session_key from CONFIG used for logging/identity (server authoritative key)
- Heartbeat default 5s (configurable)
- Optional adapter config: MTU + IP + DNS + optional persistent routes (best effort, requires admin)

Run:
  python v3-vpn_client_3_1_1.py --config client_v3.ini
"""

import argparse
import configparser
import json
import os
import queue
import signal
import socket
import struct
import subprocess
import threading
import time
from dataclasses import dataclass
from typing import Optional, Tuple, Dict

# v3.1.2: Conditional Win32 imports — protocol/config code testable on any platform.
try:
    import win32file
    import win32con
    import pywintypes
    _WIN32_OK = True
    _WIN32_IMPORT_ERROR = None
except ImportError as _e:
    _WIN32_OK = False
    _WIN32_IMPORT_ERROR = _e
    win32file = None
    win32con = None
    pywintypes = None

# Optional debugger module
try:
    from vpn_debugger import DebugProbe, ProbeConfig, setup_rotating_file_logger
except Exception:
    DebugProbe = None
    ProbeConfig = None
    setup_rotating_file_logger = None


# =========================
# Protocol
# =========================
MSG_DATA_ETHERNET = 0x01
MSG_HELLO         = 0x02
MSG_CONFIG        = 0x03
MSG_HEARTBEAT     = 0x04
MSG_STATS         = 0x05
MSG_ERROR         = 0x06

FRAME_HDR = struct.Struct("!BI")  # Type (1 byte), Length (4 bytes big-endian)


# =========================
# Helpers
# =========================
def now() -> float:
    return time.time()

def _bool(s: str) -> bool:
    return str(s).strip().lower() in ("1", "true", "yes", "y", "on")

def _int(s: str, default: int) -> int:
    try:
        return int(str(s).strip())
    except Exception:
        return default

def _float(s: str, default: float) -> float:
    try:
        return float(str(s).strip())
    except Exception:
        return default

def _csv(s: str):
    if not s.strip():
        return []
    return [x.strip() for x in s.split(",") if x.strip()]

def rate_limited(logger_fn, key: str, interval_s: float, msg: str, state: dict):
    t = state.get(key, 0.0)
    n = now()
    if n - t >= interval_s:
        state[key] = n
        logger_fn(msg)


# =========================
# Configuration
# =========================
@dataclass
class ClientConfig:
    server_host: str
    server_port: int

    client_id: str
    protocol_version: str

    tap_name: str
    tap_read_buf: int
    tap_use_overlapped: bool  # OFF by default

    max_frame_bytes: int
    ethernet_frame_max: int   # hard clamp for tunnel safety

    heartbeat_interval_s: float
    reconnect_delay_s: float
    silent_timeout_s: float

    # Apply config
    apply_ip_config: bool
    apply_mtu: bool
    apply_dns: bool
    apply_gateway: bool

    # Routes
    routes_persistent: bool
    routes: list  # "DEST/PREFIX[,GW]"

    # Debug
    debug_enabled: bool
    debug_level: str
    debug_log_file: str
    debug_also_console: bool
    debug_log_packets: bool
    debug_log_packet_hex: bool
    debug_hex_max_len: int

    pcap_enabled: bool
    pcap_dir: str
    pcap_prefix: str
    pcap_split_direction: bool


def load_config(path: str) -> ClientConfig:
    p = configparser.ConfigParser()
    p.read(path)

    def opt(sec, key, default=""):
        return p.get(sec, key, fallback=default)

    server_host = opt("client", "server_host", "127.0.0.1")
    server_port = _int(opt("client", "server_port", "4444"), 4444)

    client_id = opt("client", "client_id", socket.gethostname())
    protocol_version = opt("client", "protocol_version", "3.1.1")

    tap_name = opt("tap", "name", "N2NHU-Client-TAP")
    tap_read_buf = _int(opt("tap", "read_buf", "65536"), 65536)
    tap_use_overlapped = _bool(opt("tap", "use_overlapped", "false"))

    max_frame_bytes = _int(opt("transport", "max_frame_bytes", "262144"), 262144)
    ethernet_frame_max = _int(opt("transport", "ethernet_frame_max", "1600"), 1600)

    heartbeat_interval_s = _float(opt("transport", "heartbeat_interval_seconds", "5"), 5.0)
    reconnect_delay_s = _float(opt("transport", "reconnect_delay_seconds", "2"), 2.0)
    silent_timeout_s = _float(opt("transport", "silent_timeout_seconds", "30"), 30.0)

    apply_ip_config = _bool(opt("client", "apply_ip_config", "true"))
    apply_mtu = _bool(opt("client", "apply_mtu", "true"))
    apply_dns = _bool(opt("client", "apply_dns", "true"))
    apply_gateway = _bool(opt("client", "apply_gateway", "false"))

    routes_persistent = _bool(opt("routes", "persistent", "false"))
    routes = _csv(opt("routes", "routes", ""))

    debug_enabled = _bool(opt("debug", "enabled", "true"))
    debug_level = opt("debug", "level", "TRACE")
    debug_log_file = opt("debug", "log_file", "vpn_client_trace.log")
    debug_also_console = _bool(opt("debug", "also_console", "false"))
    debug_log_packets = _bool(opt("debug", "log_packets", "true"))
    debug_log_packet_hex = _bool(opt("debug", "log_packet_hex", "false"))
    debug_hex_max_len = _int(opt("debug", "hex_max_len", "96"), 96)

    pcap_enabled = _bool(opt("debug", "pcap_enabled", "true"))
    pcap_dir = opt("debug", "pcap_dir", "logs")
    pcap_prefix = opt("debug", "pcap_prefix", "vpn_v3")
    pcap_split_direction = _bool(opt("debug", "pcap_split_direction", "true"))

    return ClientConfig(
        server_host=server_host,
        server_port=server_port,
        client_id=client_id,
        protocol_version=protocol_version,
        tap_name=tap_name,
        tap_read_buf=tap_read_buf,
        tap_use_overlapped=tap_use_overlapped,
        max_frame_bytes=max_frame_bytes,
        ethernet_frame_max=ethernet_frame_max,
        heartbeat_interval_s=heartbeat_interval_s,
        reconnect_delay_s=reconnect_delay_s,
        silent_timeout_s=silent_timeout_s,
        apply_ip_config=apply_ip_config,
        apply_mtu=apply_mtu,
        apply_dns=apply_dns,
        apply_gateway=apply_gateway,
        routes_persistent=routes_persistent,
        routes=routes,
        debug_enabled=debug_enabled,
        debug_level=debug_level,
        debug_log_file=debug_log_file,
        debug_also_console=debug_also_console,
        debug_log_packets=debug_log_packets,
        debug_log_packet_hex=debug_log_packet_hex,
        debug_hex_max_len=debug_hex_max_len,
        pcap_enabled=pcap_enabled,
        pcap_dir=pcap_dir,
        pcap_prefix=pcap_prefix,
        pcap_split_direction=pcap_split_direction,
    )


# =========================
# Counters
# =========================
class Counters:
    def __init__(self):
        self.lock = threading.Lock()
        self.c: Dict[str, int] = {}

    def inc(self, k: str, n: int = 1):
        with self.lock:
            self.c[k] = self.c.get(k, 0) + n

    def snapshot(self) -> Dict[str, int]:
        with self.lock:
            return dict(self.c)


# =========================
# Framed socket
# =========================
class FramedSocket:
    def __init__(self, sock: socket.socket, max_frame_bytes: int, probe=None, role=""):
        self.sock = sock
        self.max_frame_bytes = max_frame_bytes
        self.probe = probe
        self.role = role
        self.send_lock = threading.Lock()

    def _recv_exact(self, n: int) -> Optional[bytes]:
        buf = b""
        while len(buf) < n:
            chunk = self.sock.recv(n - len(buf))
            if not chunk:
                return None
            buf += chunk
        return buf

    def recv_msg(self) -> Optional[Tuple[int, bytes]]:
        hdr = self._recv_exact(FRAME_HDR.size)
        if hdr is None:
            return None
        t, length = FRAME_HDR.unpack(hdr)
        if length < 0 or length > self.max_frame_bytes:
            raise ValueError(f"invalid_length={length}")
        payload = self._recv_exact(length)
        if payload is None:
            return None
        if self.probe:
            try: self.probe.msg("RX", t, length, role=self.role)
            except Exception: pass
        return t, payload

    def send_msg(self, t: int, payload: bytes):
        pkt = FRAME_HDR.pack(t, len(payload)) + payload
        with self.send_lock:
            self.sock.sendall(pkt)
        if self.probe:
            try: self.probe.msg("TX", t, len(payload), role=self.role)
            except Exception: pass


# =========================
# TAP device (sync default)
# =========================
class TapDevice:
    def __init__(self, name: str, read_buf: int, use_overlapped: bool):
        self.name = name
        self.read_buf = read_buf
        self.use_overlapped = use_overlapped
        self.handle = None

    def open(self):
        if not _WIN32_OK:
            raise RuntimeError(
                f"TAP device requires Windows + pywin32 (import error: {_WIN32_IMPORT_ERROR})"
            )
        # Best practice: set name to {GUID} in INI.
        n = self.name.strip()
        paths = []
        if n.startswith("{") and n.endswith("}"):
            paths.append(r"\\.\Global\%s.tap" % n)
        paths.append(r"\\.\Global\%s.tap" % n)

        last = None
        flags = win32con.FILE_ATTRIBUTE_SYSTEM
        if self.use_overlapped:
            flags |= win32con.FILE_FLAG_OVERLAPPED

        for p in paths:
            try:
                self.handle = win32file.CreateFile(
                    p,
                    win32con.GENERIC_READ | win32con.GENERIC_WRITE,
                    0, None, win32con.OPEN_EXISTING,
                    flags, None
                )
                return
            except pywintypes.error as e:
                last = e
        raise last or RuntimeError("Failed to open TAP device")

    def close(self):
        if self.handle:
            try:
                win32file.CancelIoEx(self.handle, None)
            except Exception:
                pass
            try:
                win32file.CloseHandle(self.handle)
            except Exception:
                pass
            self.handle = None

    def read_frame(self) -> Optional[bytes]:
        if not self.handle:
            return None

        if not self.use_overlapped:
            try:
                data = win32file.ReadFile(self.handle, self.read_buf, None)[1]
                return bytes(data)
            except pywintypes.error as e:
                if getattr(e, "winerror", None) in (109, 232, 995):
                    return None
                raise

        # Overlapped mode can be implemented later as a proper outstanding read ring.
        return None

    def write_frame(self, frame: bytes) -> bool:
        if not self.handle:
            return False
        try:
            win32file.WriteFile(self.handle, frame, None)
            return True
        except pywintypes.error as e:
            if getattr(e, "winerror", None) in (109, 232, 995):
                return False
            raise


# =========================
# Netsh / route best-effort
# =========================
def run_cmd(args, timeout=12):
    try:
        subprocess.run(args, check=False, capture_output=True, text=True, timeout=timeout)
    except Exception:
        pass

def set_mtu(ifname: str, mtu: int):
    run_cmd(["netsh", "interface", "ipv4", "set", "subinterface", ifname, f"mtu={mtu}", "store=persistent"])

def set_ip(ifname: str, ip: str, mask: str, gw: Optional[str], set_gw: bool):
    if set_gw and gw:
        run_cmd(["netsh", "interface", "ipv4", "set", "address", f"name={ifname}", "static", ip, mask, gw, "1"])
    else:
        run_cmd(["netsh", "interface", "ipv4", "set", "address", f"name={ifname}", "static", ip, mask])

def set_dns(ifname: str, dns: str):
    run_cmd(["netsh", "interface", "ipv4", "set", "dnsservers", f"name={ifname}", "static", dns, "primary"])

def add_route(dest: str, mask: str, gw: str, persistent: bool):
    cmd = ["route"]
    if persistent:
        cmd.append("-p")
    cmd += ["add", dest, "mask", mask, gw, "metric", "1"]
    run_cmd(cmd)

def prefix_to_mask(prefix: int) -> str:
    x = (0xffffffff << (32 - prefix)) & 0xffffffff
    return ".".join(str((x >> (8*i)) & 0xff) for i in [3,2,1,0])

def parse_route(spec: str):
    gw = None
    if "," in spec:
        left, gw = spec.split(",", 1)
        left = left.strip()
        gw = gw.strip()
    else:
        left = spec.strip()

    if "/" not in left:
        return None
    dest, pref = left.split("/", 1)
    dest = dest.strip()
    pref = int(pref.strip())
    return dest, prefix_to_mask(pref), gw


# =========================
# Client v3.1.1
# =========================
class VPNClientV311:
    def __init__(self, cfg: ClientConfig):
        self.cfg = cfg
        self.counters = Counters()
        self.stop_event = threading.Event()
        self.warn_state = {}

        self.session_key: Optional[str] = None
        self.assigned_cfg: Optional[dict] = None
        self.last_seen = now()

        # probe
        self.probe = None
        if DebugProbe and ProbeConfig and setup_rotating_file_logger:
            try:
                logger = setup_rotating_file_logger(
                    name="vpn-client",
                    log_file=cfg.debug_log_file,
                    level=cfg.debug_level,
                    also_console=cfg.debug_also_console
                )
                pc = ProbeConfig(
                    enabled=cfg.debug_enabled,
                    level=cfg.debug_level,
                    log_file=cfg.debug_log_file,
                    also_console=cfg.debug_also_console,
                    log_packets=cfg.debug_log_packets,
                    log_packet_hex=cfg.debug_log_packet_hex,
                    hex_max_len=cfg.debug_hex_max_len,
                    pcap_enabled=cfg.pcap_enabled,
                    pcap_dir=cfg.pcap_dir,
                    pcap_prefix=cfg.pcap_prefix,
                    pcap_split_direction=cfg.pcap_split_direction
                )
                self.probe = DebugProbe(logger, pc)
            except Exception:
                self.probe = None

        self.tap = TapDevice(cfg.tap_name, cfg.tap_read_buf, cfg.tap_use_overlapped)

        self.sock: Optional[socket.socket] = None
        self.fs: Optional[FramedSocket] = None

        self.tap_to_net_q = queue.Queue(maxsize=5000)
        self.net_to_tap_q = queue.Queue(maxsize=5000)

        self.tap_rx_thread = threading.Thread(target=self._tap_rx_loop, daemon=True)
        self.tap_tx_thread = threading.Thread(target=self._tap_tx_loop, daemon=True)

        self.net_rx_thread = None
        self.net_tx_thread = None

    def info(self, s: str):
        if self.probe:
            try: self.probe.info(s); return
            except Exception: pass
        print(s, flush=True)

    def warn(self, s: str):
        if self.probe:
            try: self.probe.warn(s); return
            except Exception: pass
        print("WARN:", s, flush=True)

    def _clamp_and_count(self, frame: bytes, origin: str) -> bool:
        # v3.1.2: drop runts (smaller than Ethernet header) and oversized
        # frames before they cross the tunnel. Keeps wire traffic clean
        # and matches the server-side bounds.
        if len(frame) < 14:
            self.counters.inc("drops.runt_eth")
            return False
        if len(frame) > self.cfg.ethernet_frame_max:
            self.counters.inc("drops.oversize_eth")
            if self.probe:
                rate_limited(self.probe.warn, f"oversize_{origin}", 2.0,
                             f"oversize_eth origin={origin} len={len(frame)} clamp={self.cfg.ethernet_frame_max}",
                             self.warn_state)
            return False
        return True

    def start(self):
        self.tap.open()
        self.tap_rx_thread.start()
        self.tap_tx_thread.start()

        while not self.stop_event.is_set():
            self._connect_run()
            if self.stop_event.is_set():
                break
            time.sleep(self.cfg.reconnect_delay_s)

        self.stop()

    def stop(self):
        self.stop_event.set()
        try:
            if self.sock:
                # v3.1.2: shutdown before close so the server's recv()
                # returns immediately instead of blocking until kernel
                # buffer pressure forces the FIN through. Prevents stale
                # sessions on the server side after graceful client exit.
                try:
                    self.sock.shutdown(socket.SHUT_RDWR)
                except OSError:
                    pass
                self.sock.close()
        except Exception:
            pass
        self.sock = None
        self.fs = None
        self.tap.close()

    def _connect_run(self):
        self.info(f"connecting to {self.cfg.server_host}:{self.cfg.server_port}")
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(10.0)
        try:
            s.connect((self.cfg.server_host, self.cfg.server_port))
        except Exception as e:
            self.warn(f"connect_failed err={e}")
            try: s.close()
            except Exception: pass
            return

        s.settimeout(None)
        self.sock = s
        self.fs = FramedSocket(s, self.cfg.max_frame_bytes, probe=self.probe, role="client")
        self.last_seen = now()

        self.net_rx_thread = threading.Thread(target=self._net_rx_loop, daemon=True)
        self.net_tx_thread = threading.Thread(target=self._net_tx_loop, daemon=True)
        self.net_rx_thread.start()
        self.net_tx_thread.start()

        # send HELLO
        hello = {
            "client_id": self.cfg.client_id,
            "protocol_version": self.cfg.protocol_version,
            "platform": "windows",
        }
        try:
            self.fs.send_msg(MSG_HELLO, json.dumps(hello).encode("utf-8"))
            self.counters.inc("tx.hello")
        except Exception as e:
            self.warn(f"hello_send_failed err={e}")
            try: self.sock.close()
            except Exception: pass
            return

        # wait until disconnect or silent timeout
        while not self.stop_event.is_set():
            if not self.net_rx_thread.is_alive() or not self.net_tx_thread.is_alive():
                break
            if now() - self.last_seen > self.cfg.silent_timeout_s:
                self.warn("server_silent_timeout")
                break
            time.sleep(0.25)

        try:
            self.sock.close()
        except Exception:
            pass
        self.counters.inc("reconnects")
        self.info("disconnected; reconnecting")

    def _net_rx_loop(self):
        assert self.fs is not None
        try:
            while not self.stop_event.is_set():
                msg = self.fs.recv_msg()
                if msg is None:
                    break
                t, payload = msg
                self.last_seen = now()
                self.counters.inc("rx.msg_total")

                if t == MSG_CONFIG:
                    self.counters.inc("rx.config")
                    try:
                        obj = json.loads(payload.decode("utf-8", errors="replace"))
                    except Exception:
                        obj = {}
                    self.assigned_cfg = obj
                    self.session_key = obj.get("session_key")
                    self.info(f"CONFIG received session_key={self.session_key} cfg={obj}")
                    self._apply_config(obj)

                elif t == MSG_DATA_ETHERNET:
                    self.counters.inc("rx.eth")
                    if self.probe:
                        try: self.probe.frame("NET_RX", payload)
                        except Exception: pass
                    if not self._clamp_and_count(payload, "net_rx"):
                        continue
                    try:
                        self.net_to_tap_q.put_nowait(payload)
                    except queue.Full:
                        self.counters.inc("drops.net_to_tap_q_full")
                        if self.probe:
                            rate_limited(self.probe.warn, "net_to_tap_q_full", 2.0,
                                         "net_to_tap_q_full (dropping under pressure)",
                                         self.warn_state)

                elif t == MSG_HEARTBEAT:
                    self.counters.inc("rx.heartbeat")

                elif t == MSG_STATS:
                    self.counters.inc("rx.stats")

                elif t == MSG_ERROR:
                    self.counters.inc("rx.error")
                    self.warn(f"SERVER_ERROR: {payload[:200]!r}")

                else:
                    self.counters.inc("rx.unknown_type")

        except Exception as e:
            self.counters.inc("errors.net_rx_exception")
            self.warn(f"net_rx_exception err={e}")
        finally:
            try:
                if self.sock:
                    self.sock.close()
            except Exception:
                pass

    def _net_tx_loop(self):
        assert self.fs is not None
        hb_next = now() + self.cfg.heartbeat_interval_s
        stats_next = now() + 5.0
        try:
            while not self.stop_event.is_set():
                t = now()
                if t >= hb_next:
                    try:
                        self.fs.send_msg(MSG_HEARTBEAT, b"")
                        self.counters.inc("tx.heartbeat")
                    except Exception:
                        break
                    hb_next = t + self.cfg.heartbeat_interval_s

                if t >= stats_next:
                    snap = self.counters.snapshot()
                    try:
                        self.fs.send_msg(MSG_STATS, json.dumps(snap).encode("utf-8"))
                        self.counters.inc("tx.stats")
                    except Exception:
                        pass
                    stats_next = t + 5.0

                try:
                    frame = self.tap_to_net_q.get(timeout=0.2)
                except queue.Empty:
                    continue

                if not self._clamp_and_count(frame, "tap_tx"):
                    continue

                if self.probe:
                    try: self.probe.frame("NET_TX", frame)
                    except Exception: pass

                try:
                    self.fs.send_msg(MSG_DATA_ETHERNET, frame)
                    self.counters.inc("tx.eth")
                except Exception:
                    break
        finally:
            try:
                if self.sock:
                    self.sock.close()
            except Exception:
                pass

    def _tap_rx_loop(self):
        while not self.stop_event.is_set():
            frame = self.tap.read_frame()
            if not frame:
                continue
            self.counters.inc("tap.rx_frames")
            if self.probe:
                try: self.probe.frame("TAP_RX", frame)
                except Exception: pass

            if not self._clamp_and_count(frame, "tap_rx"):
                continue

            try:
                self.tap_to_net_q.put_nowait(frame)
            except queue.Full:
                self.counters.inc("drops.tap_to_net_q_full")
                if self.probe:
                    rate_limited(self.probe.warn, "tap_to_net_q_full", 2.0,
                                 "tap_to_net_q_full (dropping under pressure)",
                                 self.warn_state)

    def _tap_tx_loop(self):
        while not self.stop_event.is_set():
            try:
                frame = self.net_to_tap_q.get(timeout=0.2)
            except queue.Empty:
                continue
            ok = self.tap.write_frame(frame)
            if ok:
                self.counters.inc("tap.tx_frames")
                if self.probe:
                    try: self.probe.frame("TAP_TX", frame)
                    except Exception: pass
            else:
                self.counters.inc("errors.tap_write_failed")

    def _apply_config(self, obj: dict):
        # Best-effort; safe if not admin
        if not self.cfg.apply_ip_config:
            return

        ip = obj.get("assigned_ip")
        mask = obj.get("subnet_mask")
        gw = obj.get("gateway")
        dns = obj.get("dns")

        # The server is authoritative; MTU typically 1400 but you can also set it from INI.
        mtu = _int(str(obj.get("tap_mtu", "")) or "0", 0) or None

        if ip and mask:
            if self.cfg.apply_mtu and mtu:
                set_mtu(self.cfg.tap_name, mtu)

            set_ip(self.cfg.tap_name, ip, mask, gw, self.cfg.apply_gateway)

            if self.cfg.apply_dns and dns:
                set_dns(self.cfg.tap_name, dns)

            # Optional routes
            if self.cfg.routes:
                for spec in self.cfg.routes:
                    parsed = parse_route(spec)
                    if not parsed:
                        continue
                    dest, mask2, gw2 = parsed
                    if not gw2:
                        gw2 = gw
                    if dest and mask2 and gw2:
                        add_route(dest, mask2, gw2, persistent=self.cfg.routes_persistent)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="client_v3.ini")
    args = ap.parse_args()

    cfg = load_config(args.config)
    cli = VPNClientV311(cfg)

    def handle_sig(signum, frame):
        cli.warn(f"signal {signum} received, stopping...")
        cli.stop()

    signal.signal(signal.SIGINT, handle_sig)
    signal.signal(signal.SIGTERM, handle_sig)

    cli.start()


if __name__ == "__main__":
    main()
