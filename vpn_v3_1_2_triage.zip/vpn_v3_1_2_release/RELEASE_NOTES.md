# N2NHU VPN v3.1.2 — Triage & Hardening Pass

A focused pass over v3.1.1 (Brooklyn Bridge — Layer 2 over ngrok) that
found and fixed five real bugs, made the protocol layer testable on
non-Windows hosts, and established a 42-test integration harness.

## Bugs fixed

**1. Win32 imports gated module load (portability blocker).**
`v3_1_1-vpn_server.py` and `v3_1_1-vpn_client_v2.py` had unconditional
`import win32file / win32con / pywintypes` at the top. On any host
without pywin32, the modules wouldn't import — blocking ALL testing
of the protocol/IPAM/switching layers, which are themselves fully
portable. **Fix:** wrapped imports in try/except with a `_WIN32_OK`
flag. `TapDevice.open()` now raises a clear error if pywin32 is
missing. Module import works everywhere; the TAP itself stays
Windows-only as designed.

**2. Runt-then-learn in `_tap_rx_loop` (server).**
A 12-13 byte frame would have its src MAC learned to `__LOCAL__`
(extracted from `frame[6:12]`) before the runt check at the next
stage rejected it. Result: the switch table accumulated bogus MAC
entries from malformed traffic, which could mis-route legitimate
unicast frames later. **Fix:** moved the runt check (`< 14`) before
the learn() call. A new `drops.tap_runt` counter increments on
rejection.

**3. `is_multicast_mac` IndexError on empty bytes.**
`is_multicast_mac(dst)` did `dst[0] & 1` without checking length.
No code path currently fed it empty input, but the helper was a
latent crash waiting for a malformed frame to find. **Fix:** length-
guarded both helpers — empty/short bytes are neither broadcast nor
multicast (the caller should drop them earlier as runts).

**4. Slow disconnect detection (graceful close on Linux).**
Client's `stop()` did `socket.close()` without `shutdown()`. On
Linux, this can leave the connection half-open until kernel buffer
pressure forces the FIN through — meaning the server's `recv()`
blocks for several seconds before noticing the client is gone, and
the server keeps a stale session in `clients_by_key`. **Fix:**
`stop()` now calls `shutdown(SHUT_RDWR)` before `close()`. Server
sees the disconnect immediately, frees the session, returns the
IPAM lease (well — eventually, after lease_seconds; but the session
slot is freed promptly).

**5. Client-side runt frames forwarded across the tunnel.**
The client's `_clamp_and_count` only checked the upper bound. A
runt frame from the TAP would be wrapped and sent across the ngrok
tunnel, where the server would drop it. Bandwidth waste plus
inconsistent bounds between the two ends. **Fix:** client now
drops runts at TAP RX with a `drops.runt_eth` counter, matching
server-side behavior.

## What was reviewed and left alone (deliberate design)

**IPAM keys on `session_key`, not `client_id`.** A reconnecting
client gets a fresh IP — pool addresses are burned until the
original lease expires. This is the v3.1.1 anti-spoofing design
("client_id is a label only"). Pinned by a test
(`test_reconnect_with_same_client_id_gets_new_ip`) so future
refactors can't silently change it without explicit intent. If
long-running deployments see pool exhaustion, the right knob is
shorter `ipam_lease_seconds`, not changing the key.

## Test harness: `tests/test_vpn_integration.py`

42 integration tests, ~13 seconds end-to-end, 0 skipped.

Pattern: real server + real client launched as threads in the
pytest process. `TapDevice` replaced with `FakeTap` (in-memory
queues with the same surface area: `read_frame`, `write_frame`,
`open`, `close`, plus `push_inbound` / `pop_outbound` for tests).
TCP traffic is real, on ephemeral 127.0.0.1 ports. Each test gets
a fresh tempdir and IPAM database.

Coverage:

- **TestProtocolPrimitives** — FRAME_HDR struct, broadcast/
  multicast helpers including the defensive empty-input cases
- **TestTokenBucket** — initial burst, zero-rate unlimited
  (rate_per_sec ≤ 0), time-based refill
- **TestIPAM** — first allocation, lease reuse, distinct clients,
  pool exhaustion, client_id label change, persistence across
  instances
- **TestSwitchPlane** — learn/lookup/relearn/aging
- **TestServerLifecycle** — bind, two-env coexistence
- **TestHandshake** — synthetic client over real socket: HELLO →
  CONFIG, IP in pool, two-client uniqueness, server-side tracking
- **TestEthernetForwarding** — synthetic client to TAP; TAP to
  client via flood
- **TestProtocolRobustness** — garbage payload, oversized frame,
  clean disconnect
- **TestRuntFrameHandling** — server rejects runts at both client
  and TAP ingress; pinned regression
- **TestIPAMReconnectBehavior** — documents the v3.1.1 anti-spoofing
  trade-off
- **TestMACLearning** — frame from synthetic client teaches server,
  later TAP frame routes correctly
- **TestRealClientHandshake** — full `VPNClientV311` connects,
  handshakes, stores config, appears in server table
- **TestRealClientForwarding** — real client TAP → server TAP;
  server TAP → real client TAP; **client-to-client routing via
  server switching** (the marquee test)
- **TestRealClientLifecycle** — clean disconnect propagation;
  heartbeats reach server within their interval

## Running the tests

From the release root:

    pip install pytest
    python -m pytest tests/ -v

Tests run on Linux, macOS, and Windows. Same pass results across
platforms (the FakeTap doesn't need Windows; the real TapDevice
just isn't exercised under pytest).

## What wasn't touched (known scope for future passes)

- **Real TAP behavior on Windows.** The FakeTap exercises the
  protocol layer but doesn't replicate driver-level quirks
  (overlapped I/O, ReadFile/WriteFile timing). Field-test against
  the actual Windows TAP driver remains essential before any
  major release.
- **ngrok / TLS layer.** Tests run on local TCP. The ngrok tunnel
  itself isn't simulated; the wire protocol over ngrok is identical
  to direct TCP, so the protocol-level tests cover it.
- **MTU / fragmentation under load.** The clamp-to-1600 logic is
  exercised by oversized-frame tests but real-world MTU pinch
  points (PMTU discovery on the ngrok path) aren't simulated.
- **Heartbeat timeout / silent-link recovery.** The harness exercises
  heartbeats reaching the server; the dead-link side (client doesn't
  hear server for `silent_timeout_s`) isn't yet pinned.
- **DebugProbe / pcap output.** Probe is initialized to None in
  tests for clean output. The probe and pcap paths are exercised
  manually in production but not yet under pytest.

## Files shipped

    server/
      v3_1_1-vpn_server.py             ← fixed (5 bugs above)
      server_v3.ini                    ← unchanged
      start_ngrok.bat                  ← unchanged
      tunnel-up.cmd                    ← unchanged

    client/
      v3_1_1-vpn_client_v2.py          ← fixed (runt drop + shutdown-before-close)
      client_v3.ini                    ← unchanged
      start_vpn.bat                    ← unchanged

    tests/
      test_vpn_integration.py          ← new (42 tests, ~13s)

## Sessions invested

Two focused sessions: build harness, find bugs by running, fix
each with a regression test, end-to-end client/server validation.

Note: the on-disk filenames stay `v3_1_1-` because that's what the
Windows boot scripts (start_vpn.bat) call. The fixes are tagged
v3.1.2 in the source comments and the wire protocol is unchanged,
so v3.1.2 server interoperates with v3.1.1 client and vice versa.
